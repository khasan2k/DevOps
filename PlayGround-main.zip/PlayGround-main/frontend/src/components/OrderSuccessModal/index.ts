import OrderSuccessModal from './OrderSuccessModal';

export default OrderSuccessModal;
