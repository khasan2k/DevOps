import AccountModal from './AccountModal';

export default AccountModal;
